# WebEnumMaster

**WebEnumMaster** is a powerful website enumeration tool written in Python for gathering key information about a domain.

## Features
- Resolves domain to IP
- Fetches HTTP headers
- Retrieves DNS records (A, MX, NS, TXT)
- Displays WHOIS information

## Requirements
- Python 3
- Modules: `requests`, `python-whois`, `dnspython`

Install modules using:
```bash
pip install requests python-whois dnspython
```

## Usage
```bash
python3 webenum_master.py
```

Enter the domain name when prompted.

## Legal Warning
Use this tool only for authorized testing and research.
