#!/usr/bin/env python3
import requests
import socket
import whois
import dns.resolver

def get_ip(domain):
    try:
        ip = socket.gethostbyname(domain)
        print(f"[+] IP Address: {ip}")
    except Exception as e:
        print(f"[-] Could not resolve domain: {e}")

def get_headers(domain):
    try:
        response = requests.get(f"http://{domain}", timeout=5)
        print("[+] HTTP Headers:")
        for key, value in response.headers.items():
            print(f"    {key}: {value}")
    except Exception as e:
        print(f"[-] Could not fetch headers: {e}")

def get_whois(domain):
    try:
        info = whois.whois(domain)
        print("[+] WHOIS Information:")
        print(info)
    except Exception as e:
        print(f"[-] Could not retrieve WHOIS: {e}")

def get_dns_records(domain):
    try:
        print("[+] DNS Records:")
        for qtype in ['A', 'MX', 'NS', 'TXT']:
            answers = dns.resolver.resolve(domain, qtype, raise_on_no_answer=False)
            for rdata in answers:
                print(f"    {qtype}: {rdata.to_text()}")
    except Exception as e:
        print(f"[-] Could not retrieve DNS records: {e}")

def main():
    domain = input("Enter the domain to enumerate: ").strip()
    print(f"
[*] Enumerating: {domain}
")
    get_ip(domain)
    get_headers(domain)
    get_dns_records(domain)
    get_whois(domain)

if __name__ == "__main__":
    main()
