
import socket
from concurrent.futures import ThreadPoolExecutor

def scan_port(ip, port):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(1)
            sock.connect((ip, port))
            print(f"[+] المنفذ {port} مفتوح على {ip}")
    except:
        pass

def main():
    target_ip = input("🔍 أدخل عنوان IP الهدف: ").strip()
    start_port = int(input("🔢 أدخل أول منفذ: "))
    end_port = int(input("🔢 أدخل آخر منفذ: "))

    print(f"🚀 بدأ الفحص من المنفذ {start_port} إلى {end_port} على {target_ip}...\n")

    with ThreadPoolExecutor(max_workers=100) as executor:
        for port in range(start_port, end_port + 1):
            executor.submit(scan_port, target_ip, port)

if __name__ == "__main__":
    main()
