
from scapy.all import sniff
from scapy.layers.inet import IP, TCP, UDP

def packet_callback(packet):
    if IP in packet:
        ip_layer = packet[IP]
        proto = "TCP" if TCP in packet else "UDP" if UDP in packet else "OTHER"
        print(f"[{proto}] {ip_layer.src} -> {ip_layer.dst}")

def main():
    print("🎯 بدء الالتقاط... اضغط Ctrl+C للإيقاف.")
    sniff(prn=packet_callback, store=False)

if __name__ == "__main__":
    main()
