
import hashlib

def crack_hash(hash_to_crack, wordlist_path):
    try:
        with open(wordlist_path, 'r', encoding='utf-8', errors='ignore') as file:
            for word in file:
                word = word.strip()
                hashed_word = hashlib.md5(word.encode()).hexdigest()
                if hashed_word == hash_to_crack:
                    print(f"[✓] تم العثور على كلمة المرور: {word}")
                    return
        print("[✗] لم يتم العثور على تطابق.")
    except FileNotFoundError:
        print("[!] لم يتم العثور على ملف القاموس.")

if __name__ == "__main__":
    hash_input = input("🔑 أدخل التجزئة (MD5): ").strip()
    wordlist = input("📂 أدخل مسار ملف القاموس: ").strip()
    crack_hash(hash_input, wordlist)
