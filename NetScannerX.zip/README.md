# NetScannerX

**NetScannerX** is a simple multi-threaded TCP port scanner built in Python.

## Features
- Scans TCP ports using sockets
- Multi-threaded for speed
- Lightweight and easy to use

## Requirements
- Python 3

## Usage
```bash
python3 netscannerx.py
```
Follow the prompts to enter the target IP and port range.

## Legal Warning
Use this tool only on networks and systems you have permission to scan.
