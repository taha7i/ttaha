# HashCrackPy

**HashCrackPy** is a simple hash cracker that uses a wordlist to crack MD5, SHA-1, or SHA-256 hashes.

## Features
- Supports MD5, SHA-1, SHA-256
- Easy to use with wordlist
- Written in Python 3

## Requirements
- Python 3
- A wordlist file (like rockyou.txt)

## Usage
```bash
python3 hashcrackpy.py
```
Then provide:
- The hash you want to crack
- Path to your wordlist
- Type of hash (md5, sha1, sha256)

## Legal Warning
Use this tool only for educational purposes and authorized testing.
