#!/usr/bin/env python3
import hashlib

def crack_hash(hash_to_crack, wordlist_path, hash_type):
    try:
        with open(wordlist_path, 'r', encoding='utf-8', errors='ignore') as f:
            for word in f:
                word = word.strip()
                if hash_type == 'md5':
                    hashed_word = hashlib.md5(word.encode()).hexdigest()
                elif hash_type == 'sha1':
                    hashed_word = hashlib.sha1(word.encode()).hexdigest()
                elif hash_type == 'sha256':
                    hashed_word = hashlib.sha256(word.encode()).hexdigest()
                else:
                    print("[!] Unsupported hash type.")
                    return

                if hashed_word == hash_to_crack:
                    print(f"[+] Hash cracked! Password is: {word}")
                    return
        print("[-] Password not found in wordlist.")
    except FileNotFoundError:
        print("[!] Wordlist file not found.")

def main():
    hash_to_crack = input("Enter the hash to crack: ").strip()
    wordlist_path = input("Enter path to wordlist file: ").strip()
    hash_type = input("Enter hash type (md5, sha1, sha256): ").strip().lower()

    crack_hash(hash_to_crack, wordlist_path, hash_type)

if __name__ == "__main__":
    main()
