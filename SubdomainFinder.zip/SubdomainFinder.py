
import requests

def find_subdomains(domain, wordlist_file):
    print(f"🔍 البحث عن نطاقات فرعية لـ: {domain}\n")
    try:
        with open(wordlist_file, 'r') as f:
            subdomains = f.read().splitlines()
    except FileNotFoundError:
        print(f"[!] ملف القائمة {wordlist_file} غير موجود.")
        return

    for sub in subdomains:
        url = f"http://{sub}.{domain}"
        try:
            response = requests.get(url, timeout=2)
            print(f"[+] تم العثور على نطاق فرعي: {url}")
        except requests.ConnectionError:
            pass

if __name__ == "__main__":
    domain = input("🌐 أدخل اسم النطاق (مثلاً: example.com): ")
    wordlist = input("📁 أدخل مسار ملف القائمة (wordlist.txt): ")
    find_subdomains(domain, wordlist)
